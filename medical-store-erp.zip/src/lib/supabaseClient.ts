// Supabase client helper & enterprise SQL schema generator

export const SUPABASE_SQL_SCHEMA = `-- Enterprise Pharmacy ERP Supabase PostgreSQL Schema with RLS
-- Run this in your Supabase SQL Editor to provision your production cloud database.

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. User Profiles & Roles
CREATE TABLE IF NOT EXISTS pharmacy_users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('OWNER', 'MANAGER', 'PHARMACIST', 'CASHIER', 'STAFF')),
  permissions JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Customers
CREATE TABLE IF NOT EXISTS customers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  address TEXT,
  gst_number TEXT,
  credit_limit NUMERIC DEFAULT 0,
  current_due NUMERIC DEFAULT 0,
  loyalty_points NUMERIC DEFAULT 0,
  doctor_name TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Suppliers
CREATE TABLE IF NOT EXISTS suppliers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  company_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  address TEXT,
  gst_number TEXT,
  drug_license_number TEXT,
  payment_terms TEXT,
  current_balance NUMERIC DEFAULT 0,
  bank_details JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Medicines Master
CREATE TABLE IF NOT EXISTS medicines (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  generic_name TEXT NOT NULL,
  manufacturer TEXT NOT NULL,
  category TEXT NOT NULL,
  dosage_form TEXT NOT NULL,
  strength TEXT NOT NULL,
  pack_size TEXT NOT NULL,
  hsn_code TEXT NOT NULL,
  gst_rate NUMERIC NOT NULL DEFAULT 12,
  schedule_type TEXT NOT NULL DEFAULT 'NORMAL',
  reorder_level INTEGER NOT NULL DEFAULT 20,
  max_stock_level INTEGER NOT NULL DEFAULT 200,
  requires_prescription BOOLEAN DEFAULT false,
  barcode TEXT,
  storage_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Batches (FEFO Inventory Engine)
CREATE TABLE IF NOT EXISTS medicine_batches (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  medicine_id UUID REFERENCES medicines(id) ON DELETE CASCADE,
  batch_number TEXT NOT NULL,
  mfg_date DATE NOT NULL,
  expiry_date DATE NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 0,
  available_quantity INTEGER NOT NULL DEFAULT 0,
  purchase_rate NUMERIC NOT NULL,
  mrp NUMERIC NOT NULL,
  sale_rate NUMERIC NOT NULL,
  rack_location TEXT NOT NULL,
  barcode TEXT,
  supplier_id UUID REFERENCES suppliers(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Sales Invoices
CREATE TABLE IF NOT EXISTS sales_invoices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  invoice_number TEXT UNIQUE NOT NULL,
  invoice_date TIMESTAMPTZ DEFAULT NOW(),
  invoice_type TEXT NOT NULL DEFAULT 'RETAIL',
  customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT,
  doctor_name TEXT,
  items JSONB NOT NULL,
  sub_total NUMERIC NOT NULL,
  total_discount NUMERIC NOT NULL,
  total_cgst NUMERIC NOT NULL,
  total_sgst NUMERIC NOT NULL,
  total_igst NUMERIC NOT NULL DEFAULT 0,
  round_off NUMERIC DEFAULT 0,
  grand_total NUMERIC NOT NULL,
  payment_mode TEXT NOT NULL,
  payment_status TEXT NOT NULL DEFAULT 'PAID',
  amount_paid NUMERIC NOT NULL,
  balance_due NUMERIC DEFAULT 0,
  cashier_name TEXT NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Purchases & GRN
CREATE TABLE IF NOT EXISTS purchase_entries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  grn_number TEXT UNIQUE NOT NULL,
  bill_number TEXT NOT NULL,
  bill_date DATE NOT NULL,
  supplier_id UUID REFERENCES suppliers(id),
  supplier_name TEXT NOT NULL,
  supplier_gst TEXT,
  items JSONB NOT NULL,
  sub_total NUMERIC NOT NULL,
  total_discount NUMERIC DEFAULT 0,
  total_gst NUMERIC NOT NULL,
  grand_total NUMERIC NOT NULL,
  payment_status TEXT NOT NULL DEFAULT 'UNPAID',
  amount_paid NUMERIC DEFAULT 0,
  balance_due NUMERIC NOT NULL,
  due_date DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. Operational Expenses
CREATE TABLE IF NOT EXISTS expenses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  date DATE NOT NULL,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  payment_mode TEXT NOT NULL,
  paid_to TEXT NOT NULL,
  receipt_number TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  user_id TEXT NOT NULL,
  user_name TEXT NOT NULL,
  user_role TEXT NOT NULL,
  action TEXT NOT NULL,
  module TEXT NOT NULL,
  description TEXT NOT NULL,
  metadata JSONB
);

-- 11. Enable Row Level Security (RLS)
ALTER TABLE pharmacy_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE medicines ENABLE ROW LEVEL SECURITY;
ALTER TABLE medicine_batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- 12. Permissive RLS Policies for Authenticated Staff
CREATE POLICY "Staff can view medicines" ON medicines FOR SELECT USING (true);
CREATE POLICY "Staff can insert/update medicines" ON medicines FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Staff can view sales" ON sales_invoices FOR SELECT USING (true);
CREATE POLICY "Staff can insert sales" ON sales_invoices FOR INSERT WITH CHECK (true);
`;
